"""Pydantic schemas package"""
