"""
LLM Layer for ShieldNet.

Optional intelligent analysis and explanation generation.
- Uses an OpenAI-compatible API (xAI Grok, OpenAI, local Ollama, etc.) when API key is present.
- Falls back gracefully to taxonomy + heuristics when offline or no key.
- Never sends raw PII; redacts first.
"""

import os
import json
import re
from typing import Dict, Any, List, Optional
import httpx

from backend.app.security.redaction import redact_sensitive_text
from backend.app.ml.threat_taxonomy import get_threat_explanation, THREAT_TAXONOMY

# Configuration via environment
LLM_API_BASE = os.getenv("LLM_API_BASE", "https://api.x.ai/v1")  # or https://api.openai.com/v1
LLM_API_KEY = os.getenv("LLM_API_KEY") or os.getenv("XAI_API_KEY") or os.getenv("OPENAI_API_KEY")
LLM_MODEL = os.getenv("LLM_MODEL", "grok-2-latest")  # or gpt-4o-mini, etc.
LLM_TIMEOUT = float(os.getenv("LLM_TIMEOUT", "25.0"))
LLM_ENABLED = bool(LLM_API_KEY)


SYSTEM_PROMPT = """You are ShieldNet, an expert cybersecurity assistant focused on protecting ordinary citizens (especially in India) from scams, phishing, UPI fraud, digital arrest, KYC harvesting, and social engineering.

Rules:
1. Be clear, calm, and non-alarmist. Explain risks without causing panic.
2. Always give concrete next steps the user can take right now.
3. Never ask the user for OTPs, PINs, passwords, Aadhaar, or bank details.
4. Prefer official channels: 1930 (National Cyber Crime Helpline), cybercrime.gov.in, bank official apps/numbers.
5. When analyzing a message or URL, identify the primary threat category, the social-engineering technique, and why it is effective.
6. Keep answers concise (under 250 words unless the user asks for depth).
7. If the input looks like a genuine official communication, say so and explain how to verify.
"""


def _call_llm(messages: List[Dict[str, str]], temperature: float = 0.3) -> Optional[str]:
    """Low-level chat completion call. Returns None on any failure."""
    if not LLM_ENABLED:
        return None
    try:
        headers = {
            "Authorization": f"Bearer {LLM_API_KEY}",
            "Content-Type": "application/json"
        }
        payload = {
            "model": LLM_MODEL,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": 600
        }
        with httpx.Client(timeout=LLM_TIMEOUT) as client:
            resp = client.post(f"{LLM_API_BASE.rstrip('/')}/chat/completions", headers=headers, json=payload)
            resp.raise_for_status()
            data = resp.json()
            return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        print(f"LLM call failed: {e}")
        return None


def analyze_message_with_llm(message: str, heuristic_signals: List[str] = None) -> Dict[str, Any]:
    """
    Produce a rich, educational analysis of a suspicious message.
    Returns structured dict that the API can merge with heuristic results.
    """
    safe_msg = redact_sensitive_text(message)[:2000]
    signals = heuristic_signals or []

    user_content = f"""Analyze this message for scam / social-engineering risk.

Message (PII already redacted):
\"\"\"
{safe_msg}
\"\"\"

Detected heuristic signals (if any): {signals}

Respond in the following JSON format only:
{{
  "risk_level": "LOW|MEDIUM|HIGH|CRITICAL",
  "primary_threat": "short name of main threat",
  "explanation": "2-4 sentences explaining the technique and why it is dangerous",
  "why_it_works": "1-2 sentences on the psychological lever",
  "immediate_actions": ["action 1", "action 2", "action 3"],
  "official_channels": ["1930", "cybercrime.gov.in", "..."],
  "confidence": 0.0-1.0
}}
"""

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content}
    ]

    raw = _call_llm(messages, temperature=0.2)
    if raw:
        # Try to extract JSON
        try:
            # Allow markdown code fences
            json_match = re.search(r"\{[\s\S]*\}", raw)
            if json_match:
                parsed = json.loads(json_match.group(0))
                parsed["source"] = "llm"
                parsed["model"] = LLM_MODEL
                return parsed
        except Exception:
            pass

    # Fallback to taxonomy
    tax = get_threat_explanation(signals)
    primary = tax.get("primary_threat")
    if primary:
        return {
            "risk_level": "HIGH" if signals else "MEDIUM",
            "primary_threat": primary["name"],
            "explanation": primary["description"],
            "why_it_works": primary["why_it_works"],
            "immediate_actions": primary["defense"][:3],
            "official_channels": ["1930", "cybercrime.gov.in"],
            "confidence": 0.75,
            "source": "taxonomy_fallback"
        }
    return {
        "risk_level": "LOW",
        "primary_threat": "None clearly identified",
        "explanation": "No strong scam indicators matched the known taxonomy. Still exercise normal caution with unsolicited messages.",
        "why_it_works": "",
        "immediate_actions": [
            "Do not click links or share OTPs from unsolicited messages.",
            "Verify any claim via official app or published phone number."
        ],
        "official_channels": ["1930"],
        "confidence": 0.4,
        "source": "heuristic_only"
    }


def explain_url_with_llm(url: str, features: Dict[str, float], ml_prediction: str, confidence: float) -> Dict[str, Any]:
    """Generate a human-readable explanation for a URL analysis result."""
    safe_url = redact_sensitive_text(url)[:500]
    feature_summary = ", ".join(f"{k}={v}" for k, v in features.items() if v > 0)

    user_content = f"""Explain why this URL was classified as {ml_prediction} (model confidence {confidence:.2f}).

URL: {safe_url}
Non-zero lexical features: {feature_summary}

Respond in JSON:
{{
  "summary": "1-2 sentence plain-language summary",
  "key_indicators": ["indicator 1", "indicator 2"],
  "recommended_action": "what the user should do",
  "limitations": "what this analysis cannot detect"
}}
"""

    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": user_content}
    ]
    raw = _call_llm(messages, temperature=0.2)
    if raw:
        try:
            json_match = re.search(r"\{[\s\S]*\}", raw)
            if json_match:
                parsed = json.loads(json_match.group(0))
                parsed["source"] = "llm"
                return parsed
        except Exception:
            pass

    # Static fallback
    indicators = []
    if features.get("ip_address_presence"):
        indicators.append("Raw IP address instead of a domain name")
    if features.get("shortener_presence"):
        indicators.append("URL shortener that hides the final destination")
    if features.get("punycode_presence"):
        indicators.append("Punycode (possible look-alike / homoglyph domain)")
    if features.get("suspicious_keyword_count", 0) >= 1:
        indicators.append("Contains high-risk banking / security keywords")
    if features.get("https_presence", 1) == 0:
        indicators.append("Uses insecure HTTP")

    return {
        "summary": f"The URL was classified {ml_prediction} based on lexical and structural patterns.",
        "key_indicators": indicators or ["No strong structural red flags"],
        "recommended_action": "Do not enter credentials. Navigate to the official site by typing the address yourself.",
        "limitations": "Static analysis only — does not fetch the page or check live reputation lists.",
        "source": "heuristic_fallback"
    }


def chatbot_reply(user_message: str, conversation_history: List[Dict[str, str]] = None) -> Dict[str, Any]:
    """
    Adaptive chatbot response. Uses LLM when available, otherwise falls back to
    the existing keyword FAQ knowledge base (handled by caller if needed).
    """
    safe = redact_sensitive_text(user_message)[:1500]
    history = conversation_history or []

    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    for h in history[-6:]:  # keep last few turns
        messages.append({"role": h.get("role", "user"), "content": h.get("content", "")[:800]})
    messages.append({"role": "user", "content": safe})

    reply = _call_llm(messages, temperature=0.4)
    if reply:
        return {
            "reply": reply,
            "source": "llm",
            "model": LLM_MODEL,
            "suggestions": [
                "How do I report a UPI fraud?",
                "What is digital arrest?",
                "Safe way to check a suspicious link"
            ]
        }

    # Minimal offline reply
    return {
        "reply": (
            "I am currently running in offline mode. "
            "For immediate help with a suspected scam, call the National Cyber Crime Helpline 1930 "
            "or visit https://cybercrime.gov.in. "
            "You can also use the Message Checker or URL Checker on this platform for a local analysis."
        ),
        "source": "offline_fallback",
        "suggestions": ["Report to 1930", "Check a message", "Check a URL"]
    }


def is_llm_available() -> bool:
    return LLM_ENABLED
