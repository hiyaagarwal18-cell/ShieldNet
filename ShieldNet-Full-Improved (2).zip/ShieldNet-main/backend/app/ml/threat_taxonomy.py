"""
Structured Threat Taxonomy for ShieldNet.
Provides consistent, educational explanations of modern scam techniques
(especially India-focused: UPI, KYC, digital arrest, task scams).
"""

from typing import Dict, List, Any

THREAT_TAXONOMY: Dict[str, Dict[str, Any]] = {
    "URGENCY_COERCION": {
        "name": "Urgency & Psychological Coercion",
        "category": "Social Engineering",
        "description": (
            "Attackers create artificial time pressure ('account blocked in 2 hours', "
            "'power will be cut tonight', 'last notice') to short-circuit critical thinking. "
            "Victims act before verifying."
        ),
        "common_lures": [
            "Account suspension / KYC expiry",
            "Electricity / gas disconnection",
            "Legal notice or digital arrest threat",
            "Package held at customs"
        ],
        "why_it_works": (
            "Fear of loss + scarcity bias. People over-weight immediate threats and under-weight "
            "the probability that a real bank/utility would demand action via SMS/WhatsApp."
        ),
        "defense": [
            "Pause. No legitimate institution demands instant payment or OTP via unsolicited message.",
            "Call the official number printed on your bill/card, never the number in the message.",
            "Enable transaction alerts and set daily limits."
        ],
        "related_signals": ["URGENCY", "IMPERSONATION", "OTP_REQUEST"]
    },
    "KYC_HARVESTING": {
        "name": "Fake KYC / Identity Harvesting",
        "category": "Credential & Identity Theft",
        "description": (
            "Messages claiming 'KYC pending / expired / Aadhaar-PAN linking required' "
            "lead to phishing pages or direct requests for Aadhaar, PAN, photos, or OTPs."
        ),
        "common_lures": [
            "SBI / HDFC / Axis / ICICI KYC update",
            "SIM / mobile KYC reactivation",
            "Income-tax refund linked to KYC"
        ],
        "why_it_works": (
            "Regulatory pressure is real; many citizens have received genuine KYC reminders. "
            "Attackers exploit that familiarity and the fear of account freeze."
        ),
        "defense": [
            "Banks never ask for full Aadhaar/PAN + photo + OTP via SMS link.",
            "Use only the official app or branch. Never click 'Update KYC' links in SMS.",
            "Report the number on cybercrime.gov.in / 1930."
        ],
        "related_signals": ["KYC_HARVESTING", "OTP_REQUEST", "IMPERSONATION"]
    },
    "OTP_PIN_THEFT": {
        "name": "OTP / UPI PIN / Credential Extraction",
        "category": "Credential Theft",
        "description": (
            "Direct request for OTP, UPI PIN, MPIN, or net-banking password, often under "
            "the pretext of 'verification', 'refund', or 'unblocking'."
        ),
        "common_lures": [
            "Share OTP to receive money / refund",
            "Enter UPI PIN to confirm credit",
            "Bank officer needs OTP to reverse a transaction"
        ],
        "why_it_works": (
            "Victims do not understand that OTP/PIN is a one-way authentication token. "
            "Once shared, the attacker can authorize transfers instantly."
        ),
        "defense": [
            "Never share OTP or UPI PIN with anyone — including bank staff, police, or 'support'.",
            "Banks and UPI apps never ask for your PIN to credit money.",
            "If already shared, immediately freeze the account via the official app and call the bank."
        ],
        "related_signals": ["OTP_REQUEST", "PIN_OR_PASSWORD"]
    },
    "UPI_QR_REVERSAL": {
        "name": "UPI Collect / QR Code Reversal Fraud",
        "category": "Payment Fraud",
        "description": (
            "Scammer sends a QR code or collect request claiming 'I have paid you / scan to receive'. "
            "Scanning + entering PIN debits the victim instead of crediting."
        ),
        "common_lures": [
            "OLX / Facebook Marketplace 'buyer sent money, scan to confirm'",
            "Refund / cashback QR",
            "Friend/family 'I transferred, just approve'"
        ],
        "why_it_works": (
            "Users confuse 'scan to pay' with 'scan to receive'. The UI of many apps does not make "
            "the debit direction obvious enough under social pressure."
        ),
        "defense": [
            "You NEVER need to scan a QR or enter PIN to RECEIVE money.",
            "Only enter UPI PIN when you intentionally want to SEND money.",
            "Decline unknown collect requests. Report the VPA inside the app."
        ],
        "related_signals": ["SUSPICIOUS_PAYMENT", "QR", "UPI"]
    },
    "DIGITAL_ARREST": {
        "name": "Digital Arrest / Authority Impersonation",
        "category": "Social Engineering / Extortion",
        "description": (
            "Caller claims to be police / CBI / customs / cyber cell. Victim is told a parcel "
            "contains drugs/illegal goods or an account is linked to money laundering. "
            "They demand video-call 'digital arrest' and immediate payment to 'clear the case'."
        ),
        "common_lures": [
            "Parcel from abroad with narcotics in your name",
            "Court warrant / non-bailable warrant",
            "Account used for terror financing / mule activity"
        ],
        "why_it_works": (
            "Fear of arrest + isolation (victims are told not to tell family) + authority bias. "
            "Long calls (hours) induce compliance and fatigue."
        ),
        "defense": [
            "Police / CBI never conduct 'digital arrest' over WhatsApp/Skype or demand money to personal UPI.",
            "Hang up. Call 1930 or local police station from a different phone.",
            "Do not install AnyDesk / TeamViewer / screen-sharing apps on instruction."
        ],
        "related_signals": ["IMPERSONATION", "URGENCY", "FAMILY_EMERGENCY"]
    },
    "TASK_JOB_SCAM": {
        "name": "Fake Job / Task / Merchant Scam",
        "category": "Advance-Fee / Investment Fraud",
        "description": (
            "Telegram / WhatsApp groups offer 'part-time work': like YouTube videos, rate apps, "
            "or do merchant tasks for ₹500–5000/day. After small initial payments, victims are "
            "asked for large 'security deposits' or 'tax' to unlock frozen earnings."
        ),
        "common_lures": [
            "Work from home, no experience needed",
            "Daily payout via UPI after completing tasks",
            "Upgrade to higher-paying level requires deposit"
        ],
        "why_it_works": (
            "Small early wins create commitment and sunk-cost fallacy. Victims keep depositing "
            "hoping to recover previous 'earnings'."
        ),
        "defense": [
            "Real employers never ask candidates to pay security deposits or taxes upfront.",
            "Leave the group. Do not transfer any further money.",
            "Report the group and numbers on 1930 / cybercrime.gov.in."
        ],
        "related_signals": ["FAKE_EMPLOYMENT", "ADVANCE_PAYMENT"]
    },
    "LOTTERY_PRIZE": {
        "name": "Lottery / Prize / Investment Bait",
        "category": "Baiting",
        "description": (
            "Unsolicited 'You have won KBC / iPhone / crypto airdrop / high-yield investment'. "
            "Victim must pay processing fee, tax, or send crypto to 'release' the prize."
        ),
        "common_lures": [
            "Congratulations you are selected winner",
            "Free USDT / crypto doubler",
            "Government relief / subsidy claim"
        ],
        "why_it_works": (
            "Greed + illusion of free money. People ignore base rates (almost zero chance of "
            "winning something they never entered)."
        ),
        "defense": [
            "You cannot win a lottery you never entered.",
            "Never pay fees to receive a prize or investment return.",
            "Ignore and block. Report if money already sent."
        ],
        "related_signals": ["PRIZE_OR_LOTTERY", "ADVANCE_PAYMENT"]
    },
    "FAMILY_EMERGENCY": {
        "name": "Family / Friend Emergency Impersonation",
        "category": "Social Engineering",
        "description": (
            "Message or call claiming to be a relative whose phone was lost/stolen and who needs "
            "urgent money for hospital, travel, or bail."
        ),
        "common_lures": [
            "Hi Mom/Dad, new number, phone broke",
            "Emergency hospital payment needed",
            "Stuck abroad, need temporary help"
        ],
        "why_it_works": (
            "Emotional urgency + trust in family. Victims often do not verify via a known channel."
        ),
        "defense": [
            "Call the relative on their old number or via another family member before sending money.",
            "Ask a question only the real person would know.",
            "Be extra careful with 'new number' claims."
        ],
        "related_signals": ["FAMILY_EMERGENCY", "URGENCY"]
    },
    "PHISHING_URL": {
        "name": "Phishing / Smishing Landing Page",
        "category": "Technical + Social Engineering",
        "description": (
            "Deceptive URL (often shortened or look-alike domain) leading to a cloned login page "
            "that captures credentials, OTPs, or card details."
        ),
        "common_lures": [
            "Bank login / net-banking alert",
            "Package tracking / customs fee",
            "Account verification / password reset"
        ],
        "why_it_works": (
            "Visual similarity + urgency. Users check the logo more carefully than the actual domain."
        ),
        "defense": [
            "Type the official URL yourself or use the official app.",
            "Hover / long-press links to inspect the real domain before clicking.",
            "Look for HTTPS + exact official domain (not 'sbi-secure-login.xyz')."
        ],
        "related_signals": ["suspicious_keyword", "shortener", "punycode", "ip_address"]
    }
}


def get_threat_explanation(signal_keys: List[str]) -> Dict[str, Any]:
    """
    Map detected signal keys to rich taxonomy entries.
    Returns a structured explanation block suitable for UI and reports.
    """
    matched = []
    seen = set()
    for key in signal_keys:
        key_upper = key.upper().replace(" ", "_")
        for tax_id, tax in THREAT_TAXONOMY.items():
            if key_upper in tax.get("related_signals", []) or key_upper == tax_id:
                if tax_id not in seen:
                    matched.append({
                        "id": tax_id,
                        "name": tax["name"],
                        "category": tax["category"],
                        "description": tax["description"],
                        "why_it_works": tax["why_it_works"],
                        "defense": tax["defense"],
                        "common_lures": tax.get("common_lures", [])
                    })
                    seen.add(tax_id)
    return {
        "matched_threats": matched,
        "primary_threat": matched[0] if matched else None,
        "taxonomy_version": "1.1"
    }


def get_full_taxonomy() -> Dict[str, Any]:
    return THREAT_TAXONOMY
