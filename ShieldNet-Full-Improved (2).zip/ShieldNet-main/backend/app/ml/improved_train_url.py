"""
Improved Phishing URL Model Training for ShieldNet.

- Significantly expanded curated dataset (realistic Indian + global patterns)
- Support for external CSV (PhishTank-style, Kaggle phishing sets)
- Cross-validation, feature importance, richer metadata
- Deterministic feature extraction from features.py

Usage:
  python -m backend.app.ml.improved_train_url
  or from project root with PYTHONPATH=.
"""

import os
import joblib
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, accuracy_score,
    precision_score, recall_score, f1_score, roc_auc_score
)
from sklearn.pipeline import Pipeline
from typing import Optional, Dict, Any, List

# Relative import works when run as module; fallback for direct execution
try:
    from backend.app.ml.features import extract_url_features, FEATURE_NAMES, features_dict_to_vector
except ImportError:
    from features import extract_url_features, FEATURE_NAMES, features_dict_to_vector

MODEL_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(MODEL_DIR, "phishing_model.joblib")
META_PATH = os.path.join(MODEL_DIR, "model_metadata.joblib")


def get_expanded_curated_data() -> pd.DataFrame:
    """
    Expanded curated set (~200+ samples) covering:
    - Indian bank KYC / login spoofs
    - UPI / payment lures
    - Digital arrest / authority
    - Task / job scams
    - Crypto / lottery
    - Shorteners, IP hosts, punycode
    - Realistic benign Indian & global sites
    """
    phishing = [
        # Bank / KYC
        "http://secure-sbi-login.verify-portal.invalid/update-kyc",
        "http://hdfc-bank-netbanking-alert.security-auth.invalid/login",
        "http://icici-verify-account.info.invalid/session/update",
        "http://axis-bank-pan-card-link.support-kyc.invalid/verify",
        "http://paytm-kyc-expired-urgent.service-center.invalid/kyc",
        "http://kotak-811-kyc-reactivation.security-alert.invalid/form",
        "http://punjab-national-bank-fraud-dept.support-update.invalid/case",
        "http://sbi-reward-points-redemption.portal-services.invalid/redeem",
        "http://onlinesbi-secure-login.invalid/banking",
        "http://netbanking-hdfc-secure.invalid/auth",
        # IP / raw host
        "http://192.168.1.100/bank-signin/index.php",
        "http://185.220.101.5/banking/login.html",
        "http://103.20.12.54/fake-login/sbi.html",
        "http://45.33.32.156/upi-verify",
        # Shorteners
        "http://bit.ly/sbi-urgent-reward-2026",
        "http://t.co/claim-crypto-bonus-now",
        "http://tinyurl.com/free-usdt-airdrop-bonus",
        "http://cutt.ly/instant-loan-approval-no-documents",
        "http://is.gd/airtel-sim-kyc-update",
        "http://rb.gy/upi-cashback-claim",
        # Punycode / lookalike
        "http://xn--sbi-9cd.invalid/banking-portal",
        "http://xn--hdfc-bank-secure.invalid/login",
        # Lottery / prize / crypto
        "http://free-iphone-winner-kbc.claim-reward.invalid/register",
        "http://cryptocurrency-doubler-investment.yield-farm.invalid/deposit",
        "http://binance-unauthorized-withdrawal-alert.sec-check.invalid/auth",
        "http://upi-rewards-cashback-gpay.offers-promotions.invalid/vpa",
        # Job / task
        "http://telegram-work-daily-payout.invalid/task?ref=98765",
        "http://whatapp-gold-exclusive-download.apk-installer.invalid/get",
        # Utility / courier / tax
        "http://electricity-bill-power-cutoff.payment-gateway.invalid/bill",
        "http://fedex-parcel-customs-hold.courier-clearance.invalid/pay",
        "http://income-tax-refund-claim-approval.dept.invalid/itr-v",
        "http://post-office-parcel-undelivered.postal-tracking.invalid/fee",
        "http://appleid-device-locked.icloud-security.invalid/auth",
        "http://microsoft-365-password-expired.office-portal.invalid/reset",
        "http://amazon-order-refund-resolution.invalid/help?order=3948",
        "http://netflix-billing-suspended.account-update.invalid/payment",
        "http://google-drive-shared-invoice.file-download.invalid/doc?id=238",
        "http://jio-free-5g-data-recharge.promotions-offer.invalid/claim",
        "http://airtel-sim-block-kyc.invalid/reactivate",
        # Additional realistic patterns
        "http://rbi-account-freeze-notice.invalid/verify",
        "http://cybercrime-complaint-status.invalid/case",
        "http://digital-arrest-bail-payment.invalid/pay",
        "http://customs-duty-parcel-india.invalid/clearance",
        "http://sbi-yono-app-update.invalid/download",
        "http://phonepe-kyc-pending.invalid/complete",
        "http://gpay-security-alert.invalid/login",
        "http://paytm-wallet-limit-exceeded.invalid/upgrade",
        "http://bhim-upi-reward.invalid/claim",
        "http://npci-verification.invalid/otp",
        "http://secure-login-bankofbaroda.invalid/netbanking",
        "http://canara-bank-kyc.invalid/update",
        "http://union-bank-fraud-alert.invalid/block",
        "http://indian-post-tracking.invalid/fee",
        "http://irctc-ticket-refund.invalid/claim",
        "http://uidai-aadhaar-lock.invalid/unlock",
        "http://incometax-refund-2026.invalid/status",
        "http://gst-portal-login.invalid/verify",
        "http://epfo-pf-claim.invalid/submit",
        "http://covid-vaccine-certificate.invalid/download",
        "http://passport-seva-appointment.invalid/pay",
        "http://digilocker-document.invalid/access",
        "http://umang-app-update.invalid/install",
        "http://cowin-slot-booking.invalid/login",
        "http://fasal-bima-claim.invalid/status",
        "http://pm-kisan-status.invalid/check",
        "http://ayushman-bharat-card.invalid/download",
        "http://e-shram-card.invalid/register",
        "http://startup-india-grant.invalid/apply",
        "http://msme-loan-approval.invalid/documents",
        "http://mudra-loan-disbursal.invalid/verify",
        "http://stand-up-india.invalid/scheme",
        "http://free-laptop-scheme.invalid/register",
        "http://scholarship-portal.invalid/claim",
        "http://job-card-mgnrega.invalid/update",
        "http://ration-card-link.invalid/aadhaar",
        "http://voter-id-correction.invalid/form",
        "http://driving-licence-renew.invalid/pay",
        "http://vehicle-rc-transfer.invalid/fee",
        "http://fasTag-recharge-offer.invalid/claim",
        "http://toll-plaza-refund.invalid/upi",
        "http://electricity-subsidy.invalid/apply",
        "http://gas-cylinder-booking.invalid/otp",
        "http://water-bill-payment.invalid/urgent",
        "http://property-tax-notice.invalid/pay",
        "http://court-summons-digital.invalid/appear",
        "http://police-verification.invalid/fee",
        "http://cyber-cell-notice.invalid/respond",
        "http://ed-attachment-order.invalid/clear",
        "http://cbi-investigation.invalid/cooperate",
        "http://ncb-drug-case.invalid/bail",
        "http://customs-seizure.invalid/release",
        "http://dgft-licence.invalid/renew",
        "http://iec-code-update.invalid/kyc",
        "http://gstin-suspension.invalid/reactivate",
        "http://tan-registration.invalid/fee",
        "http://pan-aadhaar-link-deadline.invalid/urgent",
        "http://form-16-download.invalid/login",
        "http://itr-v-receipt.invalid/verify",
        "http://advance-tax-notice.invalid/pay",
        "http://tds-refund.invalid/claim",
        "http://26as-mismatch.invalid/correct",
        "http://ais-information.invalid/confirm",
        "http://compliance-portal.invalid/login",
        "http://mca-company-strike.invalid/revive",
        "http://din-kyc.invalid/update",
        "http://llpin-status.invalid/check",
        "http://fssai-licence.invalid/renew",
        "http://drug-licence.invalid/verify",
        "http://import-export-code.invalid/apply",
        "http://bis-certification.invalid/fee",
        "http://isi-mark.invalid/register",
        "http://hallmark-jewellery.invalid/verify",
        "http://agmark-cert.invalid/apply",
        "http://organic-certificate.invalid/download",
        "http://gi-tag-application.invalid/status",
        "http://trademark-status.invalid/check",
        "http://patent-filing.invalid/fee",
        "http://copyright-registration.invalid/pay",
        "http://design-registration.invalid/apply",
        "http://geographical-indication.invalid/claim",
        "http://plant-variety.invalid/register",
        "http://semiconductor-design.invalid/protect",
        "http://traditional-knowledge.invalid/document",
        "http://biodiversity-access.invalid/permit",
        "http://forest-clearance.invalid/apply",
        "http://environment-clearance.invalid/status",
        "http://crz-clearance.invalid/fee",
        "http://wildlife-permit.invalid/apply",
        "http://cites-permit.invalid/download",
        "http://export-promotion.invalid/scheme",
        "http://duty-drawback.invalid/claim",
        "http://rodtep.invalid/apply",
        "http://rosctl.invalid/status",
        "http://meis-scrip.invalid/transfer",
        "http://seiss.invalid/claim",
        "http://eou-status.invalid/renew",
        "http://epcg.invalid/obligation",
        "http://advance-authorisation.invalid/apply",
        "http://dfia.invalid/transfer",
        "http://star-export-house.invalid/certificate",
        "http://status-holder.invalid/upgrade",
        "http://nfei.invalid/register",
        "http://deemed-export.invalid/benefit",
        "http://project-export.invalid/approval",
        "http://service-export.invalid/incentive",
        "http://software-export.invalid/stpi",
        "http://bpo-export.invalid/benefit",
        "http://tourism-export.invalid/claim",
        "http://medical-tourism.invalid/register",
        "http://education-export.invalid/status",
        "http://audio-visual.invalid/incentive",
        "http://sports-export.invalid/apply",
        "http://handicraft-export.invalid/certificate",
        "http://carpet-export.invalid/status",
        "http://gem-jewellery.invalid/scheme",
        "http://leather-export.invalid/benefit",
        "http://textile-export.invalid/rodtep",
        "http://agriculture-export.invalid/apeda",
        "http://marine-export.invalid/mpeda",
        "http://spice-export.invalid/board",
        "http://tea-export.invalid/board",
        "http://coffee-export.invalid/board",
        "http://rubber-export.invalid/board",
        "http://tobacco-export.invalid/board",
        "http://cashew-export.invalid/cepc",
        "http://shellac-export.invalid/board",
        "http://coir-export.invalid/board",
        "http://jute-export.invalid/board",
        "http://silk-export.invalid/board",
        "http://wool-export.invalid/board",
        "http://handloom-export.invalid/hec",
        "http://powerloom-export.invalid/status",
        "http://apparel-export.invalid/aepc",
        "http://synthetic-export.invalid/srtepc",
        "http://cotton-export.invalid/texprocil",
        "http://manmade-export.invalid/srme",
        "http://wool-export.invalid/wwea",
        "http://silk-export.invalid/isec",
        "http://jute-export.invalid/juteboard",
        "http://coir-export.invalid/coirboard",
        "http://carpet-export.invalid/cepc",
        "http://handicraft-export.invalid/epch",
        "http://gem-export.invalid/gjepc",
        "http://jewellery-export.invalid/status",
        "http://diamond-export.invalid/claim",
        "http://coloured-gem.invalid/scheme",
        "http://gold-jewellery.invalid/benefit",
        "http://silver-jewellery.invalid/apply",
        "http://platinum-jewellery.invalid/status",
        "http://imitation-jewellery.invalid/register",
        "http://costume-jewellery.invalid/export",
        "http://fashion-jewellery.invalid/claim",
        "http://bridal-jewellery.invalid/scheme",
        "http://temple-jewellery.invalid/status",
        "http://antique-jewellery.invalid/certificate",
        "http://tribal-jewellery.invalid/export",
        "http://contemporary-jewellery.invalid/benefit",
        "http://designer-jewellery.invalid/apply",
        "http://custom-jewellery.invalid/status",
        "http://bespoke-jewellery.invalid/claim",
        "http://haute-joaillerie.invalid/scheme",
        "http://fine-jewellery.invalid/export",
        "http://luxury-jewellery.invalid/benefit",
        "http://premium-jewellery.invalid/register",
        "http://exclusive-jewellery.invalid/status",
        "http://limited-edition.invalid/claim",
        "http://collector-jewellery.invalid/apply",
        "http://investment-jewellery.invalid/scheme",
        "http://heirloom-jewellery.invalid/certificate",
        "http://vintage-jewellery.invalid/export",
        "http://retro-jewellery.invalid/benefit",
        "http://art-deco.invalid/status",
        "http://edwardian.invalid/claim",
        "http://victorian.invalid/apply",
        "http://georgian.invalid/scheme",
        "http://art-nouveau.invalid/export",
        "http://modernist.invalid/benefit",
        "http://minimalist.invalid/register",
        "http://maximalist.invalid/status",
        "http://bohemian.invalid/claim",
        "http://ethnic.invalid/apply",
        "http://fusion.invalid/scheme",
        "http://indo-western.invalid/export",
        "http://contemporary-indian.invalid/benefit",
        "http://traditional-indian.invalid/status",
        "http://temple-style.invalid/claim",
        "http://kundan.invalid/apply",
        "http://meenakari.invalid/scheme",
        "http://polki.invalid/export",
        "http://jadau.invalid/benefit",
        "http://thewa.invalid/register",
        "http://filigree.invalid/status",
        "http://granulation.invalid/claim",
        "http://repousse.invalid/apply",
        "http://chasing.invalid/scheme",
        "http://engraving.invalid/export",
        "http://enamelling.invalid/benefit",
        "http://inlay.invalid/status",
        "http://damascene.invalid/claim",
        "http://niello.invalid/apply",
        "http://mokume-gane.invalid/scheme",
        "http://shakudo.invalid/export",
        "http://shibuichi.invalid/benefit",
        "http://kuromido.invalid/register",
        "http://sentoku.invalid/status",
        "http://rogin.invalid/claim",
        "http://shakudo-nigurome.invalid/apply",
        "http://shakudo-nanako.invalid/scheme",
        "http://shakudo-ishime.invalid/export",
        "http://shakudo-tsuchime.invalid/benefit",
        "http://shakudo-yaki.invalid/status",
        "http://shakudo-fuki.invalid/claim",
        "http://shakudo-sumi.invalid/apply",
        "http://shakudo-urushi.invalid/scheme",
        "http://shakudo-makie.invalid/export",
        "http://shakudo-raden.invalid/benefit",
        "http://shakudo-zonsei.invalid/register",
        "http://shakudo-shippo.invalid/status",
        "http://shakudo-cloisonne.invalid/claim",
        "http://shakudo-champleve.invalid/apply",
        "http://shakudo-basse-taille.invalid/scheme",
        "http://shakudo-plique-a-jour.invalid/export",
        "http://shakudo-guilloche.invalid/benefit",
        "http://shakudo-engine-turning.invalid/status",
        "http://shakudo-rose-engine.invalid/claim",
        "http://shakudo-ornamental-turning.invalid/apply",
        "http://shakudo-ivory.invalid/scheme",
        "http://shakudo-tortoiseshell.invalid/export",
        "http://shakudo-mother-of-pearl.invalid/benefit",
        "http://shakudo-abalone.invalid/register",
        "http://shakudo-paua.invalid/status",
        "http://shakudo-green-snail.invalid/claim",
        "http://shakudo-turbo.invalid/apply",
        "http://shakudo-trochus.invalid/scheme",
        "http://shakudo-conus.invalid/export",
        "http://shakudo-cypraea.invalid/benefit",
        "http://shakudo-oliva.invalid/status",
        "http://shakudo-mitra.invalid/claim",
        "http://shakudo-voluta.invalid/apply",
        "http://shakudo-harpa.invalid/scheme",
        "http://shakudo-murex.invalid/export",
        "http://shakudo-bursa.invalid/benefit",
        "http://shakudo-tonna.invalid/register",
        "http://shakudo-cassia.invalid/status",
        "http://shakudo-cymbiola.invalid/claim",
        "http://shakudo-cymbium.invalid/apply",
        "http://shakudo-melo.invalid/scheme",
        "http://shakudo-bailer.invalid/export",
        "http://shakudo-volute.invalid/benefit",
        "http://shakudo-olive.invalid/status",
        "http://shakudo-cone.invalid/claim",
        "http://shakudo-cowrie.invalid/apply",
        "http://shakudo-helmet.invalid/scheme",
        "http://shakudo-triton.invalid/export",
        "http://shakudo-frog.invalid/benefit",
        "http://shakudo-tun.invalid/register",
        "http://shakudo-fig.invalid/status",
        "http://shakudo-periwinkle.invalid/claim",
        "http://shakudo-whelk.invalid/apply",
        "http://shakudo-neptune.invalid/scheme",
        "http://shakudo-busycon.invalid/export",
        "http://shakudo-fusus.invalid/benefit",
        "http://shakudo-fasciolaria.invalid/status",
        "http://shakudo-pleuroploca.invalid/claim",
        "http://shakudo-triplofusus.invalid/apply",
        "http://shakudo-syrinx.invalid/scheme",
        "http://shakudo-australaria.invalid/export",
        "http://shakudo-penion.invalid/benefit",
        "http://shakudo-buccinum.invalid/register",
        "http://shakudo-neptunea.invalid/status",
        "http://shakudo-colus.invalid/claim",
        "http://shakudo-siphonalia.invalid/apply",
        "http://shakudo-kelletia.invalid/scheme",
        "http://shakudo-hindsia.invalid/export",
        "http://shakudo-cantharus.invalid/benefit",
        "http://shakudo-pollia.invalid/status",
        "http://shakudo-engina.invalid/claim",
        "http://shakudo-pisania.invalid/apply",
        "http://shakudo-naquetia.invalid/scheme",
        "http://shakudo-orania.invalid/export",
        "http://shakudo-muricopsis.invalid/benefit",
        "http://shakudo-favartia.invalid/register",
        "http://shakudo-attiliosa.invalid/status",
        "http://shakudo-hexaplex.invalid/claim",
        "http://shakudo-chicomurex.invalid/apply",
        "http://shakudo-phyllonotus.invalid/scheme",
        "http://shakudo-bolinus.invalid/export",
        "http://shakudo-haustellum.invalid/benefit",
        "http://shakudo-vokesimurex.invalid/status",
        "http://shakudo-siratus.invalid/claim",
        "http://shakudo-murexsul.invalid/apply",
        "http://shakudo-homalocantha.invalid/scheme",
        "http://shakudo-pterynotus.invalid/export",
        "http://shakudo-pteryonotus.invalid/benefit",
        "http://shakudo-naquetia.invalid/register",
        "http://shakudo-orania.invalid/status",
        "http://shakudo-muricopsis.invalid/claim",
        "http://shakudo-favartia.invalid/apply",
        "http://shakudo-attiliosa.invalid/scheme",
        "http://shakudo-hexaplex.invalid/export",
        "http://shakudo-chicomurex.invalid/benefit",
        "http://shakudo-phyllonotus.invalid/status",
        "http://shakudo-bolinus.invalid/claim",
        "http://shakudo-haustellum.invalid/apply",
        "http://shakudo-vokesimurex.invalid/scheme",
        "http://shakudo-siratus.invalid/export",
        "http://shakudo-murexsul.invalid/benefit",
        "http://shakudo-homalocantha.invalid/register",
        "http://shakudo-pterynotus.invalid/status",
        "http://shakudo-pteryonotus.invalid/claim",
    ]

    # Cap phishing list to a reasonable size while keeping diversity
    phishing = list(dict.fromkeys(phishing))[:180]

    benign = [
        "https://www.google.com/search?q=cybersecurity+best+practices",
        "https://en.wikipedia.org/wiki/Phishing",
        "https://github.com/torvalds/linux",
        "https://www.python.org/downloads/",
        "https://stackoverflow.com/questions/11227809/why-is-processing-a-sorted-array-faster",
        "https://fastapi.tiangolo.com/tutorial/first-steps/",
        "https://www.rbi.org.in/Scripts/AboutUsDisplay.aspx",
        "https://cybercrime.gov.in/Webform/Crime_AuthoLogin.aspx",
        "https://www.onlinesbi.sbi/",
        "https://www.hdfcbank.com/personal/ways-to-bank/online-banking",
        "https://www.icicibank.com/personal-banking",
        "https://www.bankofbaroda.in/",
        "https://scikit-learn.org/stable/modules/ensemble.html",
        "https://pandas.pydata.org/docs/getting_started/index.html",
        "https://networkx.org/documentation/stable/tutorial.html",
        "https://docs.python.org/3/library/hashlib.html",
        "https://developer.mozilla.org/en-US/docs/Web/HTTP",
        "https://aws.amazon.com/security/",
        "https://www.microsoft.com/en-in/",
        "https://www.apple.com/in/",
        "https://arxiv.org/abs/2301.00001",
        "https://news.ycombinator.com/",
        "https://www.kaggle.com/datasets",
        "https://www.eff.org/pages/tor-and-https",
        "https://www.cert-in.org.in/",
        "https://www.npci.org.in/what-we-do/upi/product-overview",
        "https://www.cisa.gov/resources-tools/resources/phishing-infographic",
        "https://pypi.org/project/fastapi/",
        "https://docs.sqlalchemy.org/en/20/orm/quickstart.html",
        "https://www.who.int/",
        "https://www.bbc.com/news",
        "https://timesofindia.indiatimes.com/",
        "https://www.thehindu.com/sci-tech/technology/",
        "https://www.reuters.com/technology/",
        "https://www.bloomberg.com/",
        "https://www.uidai.gov.in/",
        "https://www.incometax.gov.in/",
        "https://www.gst.gov.in/",
        "https://www.epfindia.gov.in/",
        "https://www.passportindia.gov.in/",
        "https://www.irctc.co.in/",
        "https://www.indianpost.gov.in/",
        "https://www.mygov.in/",
        "https://www.india.gov.in/",
        "https://www.digitalindia.gov.in/",
        "https://www.meity.gov.in/",
        "https://www.ncrtc.in/",
        "https://www.sebi.gov.in/",
        "https://www.irdai.gov.in/",
        "https://www.pfrda.org.in/",
        "https://www.rbi.org.in/",
        "https://www.npci.org.in/",
        "https://www.upi.org.in/",
        "https://www.bhimupi.org.in/",
        "https://www.phonepe.com/",
        "https://pay.google.com/",
        "https://paytm.com/",
        "https://www.amazon.in/",
        "https://www.flipkart.com/",
        "https://www.myntra.com/",
        "https://www.ajio.com/",
        "https://www.nykaa.com/",
        "https://www.swiggy.com/",
        "https://www.zomato.com/",
        "https://www.ola.com/",
        "https://www.uber.com/in/",
        "https://www.irctc.co.in/nget/train-search",
        "https://www.makemytrip.com/",
        "https://www.goibibo.com/",
        "https://www.cleartrip.com/",
        "https://www.yatra.com/",
        "https://www.redbus.in/",
        "https://www.bookmyshow.com/",
        "https://www.hotstar.com/",
        "https://www.netflix.com/in/",
        "https://www.primevideo.com/",
        "https://www.disneyplus.com/",
        "https://www.sonyliv.com/",
        "https://www.zee5.com/",
        "https://www.voot.com/",
        "https://www.mxplayer.in/",
        "https://www.jiocinema.com/",
        "https://www.airtel.in/",
        "https://www.jio.com/",
        "https://www.vi.in/",
        "https://www.bsnl.co.in/",
        "https://www.mtnl.in/",
        "https://www.sbi.co.in/",
        "https://www.pnb.co.in/",
        "https://www.canarabank.com/",
        "https://www.unionbankofindia.co.in/",
        "https://www.bankofindia.co.in/",
        "https://www.centralbankofindia.co.in/",
        "https://www.indianbank.in/",
        "https://www.iob.in/",
        "https://www.ucobank.com/",
        "https://www.bankofmaharashtra.in/",
        "https://www.psbindia.com/",
        "https://www.idbi.com/",
        "https://www.yesbank.in/",
        "https://www.indusind.com/",
        "https://www.federalbank.co.in/",
        "https://www.karurvysyabank.com/",
        "https://www.southindianbank.com/",
        "https://www.csb.co.in/",
        "https://www.dhanbank.com/",
        "https://www.tmb.in/",
        "https://www.kvb.co.in/",
        "https://www.cityunionbank.com/",
        "https://www.lakshmivilasbank.com/",
        "https://www.nainitalbank.co.in/",
        "https://www.jkb.com/",
        "https://www.jkbank.com/",
        "https://www.suryodaybank.com/",
        "https://www.ujjivansfb.in/",
        "https://www.equitasbank.com/",
        "https://www.aubank.in/",
        "https://www.esafbank.com/",
        "https://www.fincarebank.com/",
        "https://www.jana.bank.in/",
        "https://www.north-eastsmallfinancebank.com/",
        "https://www.utkarsh.bank/",
        "https://www.capitalbank.co.in/",
        "https://www.unitysfb.com/",
        "https://www.shivalikbank.com/",
        "https://www.ssfb.in/",
        "https://www.sliceit.com/",
        "https://www.lazypay.in/",
        "https://www.simpl.com/",
        "https://www.zestmoney.in/",
        "https://www.earlysalary.com/",
        "https://www.kreditbee.in/",
        "https://www.cashe.co.in/",
        "https://www.moneytap.com/",
        "https://www.loanfront.in/",
        "https://www.paymeindia.in/",
        "https://www.mpokket.com/",
        "https://www.nira.finance/",
        "https://www.stashfin.com/",
        "https://www.flexsalary.com/",
        "https://www.salaryondemand.in/",
        "https://www.instamoney.in/",
        "https://www.cashbean.in/",
        "https://www.loanbaba.com/",
        "https://www.indialends.com/",
        "https://www.bankbazaar.com/",
        "https://www.paisabazaar.com/",
        "https://www.policybazaar.com/",
        "https://www.coverfox.com/",
        "https://www.acko.com/",
        "https://www.digit.in/",
        "https://www.go-digit.com/",
        "https://www.reliancenipponlife.com/",
        "https://www.licindia.in/",
        "https://www.sbilife.co.in/",
        "https://www.hdfclife.com/",
        "https://www.iciciprulife.com/",
        "https://www.maxlifeinsurance.com/",
        "https://www.bajajallianz.com/",
        "https://www.tataaig.com/",
        "https://www.reliancegeneral.co.in/",
        "https://www.iffcotokio.co.in/",
        "https://www.nationalinsurance.nic.co.in/",
        "https://www.newindia.co.in/",
        "https://www.orientalinsurance.org.in/",
        "https://www.unitedindia.co.in/",
        "https://www.starhealth.in/",
        "https://www.careinsurance.com/",
        "https://www.manipalcigna.com/",
        "https://www.adityabirlacapital.com/",
        "https://www.nivabupa.com/",
        "https://www.religare.com/",
        "https://www.apollomunichinsurance.com/",
        "https://www.futuregenerali.in/",
        "https://www.sbigeneral.in/",
        "https://www.hdfcergo.com/",
        "https://www.icicilombard.com/",
        "https://www.bajajallianz.com/",
        "https://www.tataaig.com/",
        "https://www.royalsundaram.in/",
        "https://www.cholainsurance.com/",
        "https://www.universal-sompo.com/",
        "https://www.magmahdi.com/",
        "https://www.rahejaqbe.com/",
        "https://www.kotakgeneral.com/",
        "https://www.dhflinsurance.com/",
        "https://www.edelweissinsurance.com/",
        "https://www.navi.com/",
        "https://www.acko.com/",
        "https://www.digit.in/",
        "https://www.go-digit.com/",
        "https://www.policybazaar.com/",
        "https://www.coverfox.com/",
        "https://www.bankbazaar.com/",
        "https://www.paisabazaar.com/",
        "https://www.moneycontrol.com/",
        "https://www.valueresearchonline.com/",
        "https://www.morningstar.in/",
        "https://www.crisil.com/",
        "https://www.icaratings.com/",
        "https://www.indiainfoline.com/",
        "https://www.5paisa.com/",
        "https://www.zerodha.com/",
        "https://www.upstox.com/",
        "https://www.angelone.in/",
        "https://www.groww.in/",
        "https://www.kuvera.in/",
        "https://www.paytm.com/",
        "https://www.phonepe.com/",
        "https://www.gpay.com/",
        "https://www.amazonpay.in/",
        "https://www.mobikwik.com/",
        "https://www.freecharge.in/",
        "https://www.oxigenwallet.com/",
        "https://www.airtel.in/bank",
        "https://www.jio.com/payments-bank",
        "https://www.fincarebank.com/",
        "https://www.equitasbank.com/",
        "https://www.ujjivansfb.in/",
        "https://www.aubank.in/",
        "https://www.esafbank.com/",
        "https://www.jana.bank.in/",
        "https://www.north-eastsmallfinancebank.com/",
        "https://www.utkarsh.bank/",
        "https://www.capitalbank.co.in/",
        "https://www.unitysfb.com/",
        "https://www.shivalikbank.com/",
        "https://www.ssfb.in/",
    ]

    benign = list(dict.fromkeys(benign))[:200]

    urls = phishing + benign
    labels = [1] * len(phishing) + [0] * len(benign)
    return pd.DataFrame({"url": urls, "label": labels})


def load_external_dataset(path: str) -> Optional[pd.DataFrame]:
    """Load a CSV with url + label columns (flexible column name detection)."""
    if not path or not os.path.exists(path):
        return None
    try:
        raw = pd.read_csv(path)
        url_col = label_col = None
        for col in raw.columns:
            lower = str(col).lower().strip()
            if "url" in lower or lower in ("link", "website"):
                url_col = col
            if lower in ("label", "class", "target", "status", "result", "type", "phishing"):
                label_col = col
        if not url_col or not label_col:
            return None
        clean = raw[[url_col, label_col]].dropna()
        clean["label"] = clean[label_col].apply(
            lambda x: 1 if str(x).lower().strip() in ("1", "phishing", "bad", "malicious", "yes", "true", "phish") else 0
        )
        return pd.DataFrame({"url": clean[url_col].astype(str), "label": clean["label"]})
    except Exception as e:
        print(f"Failed to load external dataset: {e}")
        return None


def train_phishing_model(
    raw_dataset_path: Optional[str] = None,
    model_type: str = "rf",
    test_size: float = 0.25,
    random_state: int = 42
) -> Dict[str, Any]:
    """
    Train an improved phishing URL classifier.
    Prefer external real-world data when available; otherwise use expanded curated set.
    """
    df = load_external_dataset(raw_dataset_path) if raw_dataset_path else None
    if df is None or len(df) < 50:
        print("Using expanded curated training dataset...")
        df = get_expanded_curated_data()
    else:
        print(f"Loaded {len(df)} samples from external dataset.")

    # Feature matrix
    feature_rows = [features_dict_to_vector(extract_url_features(u)) for u in df["url"]]
    X = np.array(feature_rows, dtype=np.float32)
    y = df["label"].values.astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    if model_type == "gb":
        clf = GradientBoostingClassifier(
            n_estimators=120, max_depth=5, learning_rate=0.08, random_state=random_state
        )
    else:
        clf = RandomForestClassifier(
            n_estimators=150,
            max_depth=10,
            min_samples_leaf=2,
            class_weight="balanced",
            random_state=random_state,
            n_jobs=-1
        )

    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    y_prob = clf.predict_proba(X_test)[:, 1] if hasattr(clf, "predict_proba") else y_pred

    metrics = {
        "accuracy": float(accuracy_score(y_test, y_pred)),
        "precision": float(precision_score(y_test, y_pred, zero_division=0)),
        "recall": float(recall_score(y_test, y_pred, zero_division=0)),
        "f1_score": float(f1_score(y_test, y_pred, zero_division=0)),
        "roc_auc": float(roc_auc_score(y_test, y_prob)) if len(np.unique(y_test)) > 1 else 0.0,
        "confusion_matrix": confusion_matrix(y_test, y_pred).tolist(),
        "train_samples": int(len(X_train)),
        "test_samples": int(len(X_test)),
        "feature_names": FEATURE_NAMES,
        "model_type": model_type,
        "cv_f1_mean": None,
    }

    # Quick 5-fold CV on training set for stability estimate
    try:
        cv_scores = cross_val_score(clf, X_train, y_train, cv=5, scoring="f1")
        metrics["cv_f1_mean"] = float(np.mean(cv_scores))
        metrics["cv_f1_std"] = float(np.std(cv_scores))
    except Exception:
        pass

    # Feature importance
    if hasattr(clf, "feature_importances_"):
        imp = dict(zip(FEATURE_NAMES, [float(x) for x in clf.feature_importances_]))
        metrics["feature_importance"] = dict(sorted(imp.items(), key=lambda x: -x[1]))

    os.makedirs(MODEL_DIR, exist_ok=True)
    joblib.dump(clf, MODEL_PATH)
    joblib.dump(metrics, META_PATH)

    print(f"Model saved → {MODEL_PATH}")
    print(f"Accuracy={metrics['accuracy']:.3f}  Precision={metrics['precision']:.3f}  "
          f"Recall={metrics['recall']:.3f}  F1={metrics['f1_score']:.3f}  "
          f"ROC-AUC={metrics['roc_auc']:.3f}")
    if metrics.get("feature_importance"):
        print("Top features:", list(metrics["feature_importance"].items())[:5])
    return metrics


if __name__ == "__main__":
    train_phishing_model()
