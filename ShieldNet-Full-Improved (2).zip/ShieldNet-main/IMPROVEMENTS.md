# ShieldNet — Analysis, Flaws & Improvements

**Date**: 2026-11-14  
**Scope**: Full codebase review + concrete enhancements for LLM layer, model training, datasets, and threat explanations.

---

## 1. Executive Summary of Flaws

| # | Flaw | Evidence | Risk |
|---|------|----------|------|
| 1 | Extremely small training set for URL model (~70 samples) | `train_model.py` curated lists | Model overfits; fails on real phishing |
| 2 | Message analysis is pure regex | `message_analysis.py` SIGNAL_PATTERNS | Misses paraphrase, code-mixing, new campaigns |
| 3 | No LLM / generative layer | Chatbot = keyword FAQ only | Brittle explanations & education |
| 4 | Datasets advertised but only synthetic seed present | README claims PaySim/PhishTank/Elliptic | Graph intelligence is demo-only |
| 5 | Threat explanations are shallow templates | Various services | Users learn less about *why* attacks work |
| 6 | No continuous training / feature-importance path | Single RF dump | Hard to iterate |
| 7 | India-specific patterns strong in heuristics, weak in training data | UPI/KYC/digital-arrest covered in rules only | Local model under-trained |

**Strengths retained**: privacy-first design (consent gating, redaction, SSRF-safe), NetworkX graph, Cytoscape UI, good test coverage, offline-capable core.

---

## 2. Improvements Delivered

### 2.1 Expanded & Realistic Training Data
- New file: `backend/app/ml/improved_train_url.py`
- ~180 phishing + ~200 benign curated samples covering:
  - Indian bank KYC / net-banking spoofs
  - UPI / PhonePe / GPay / Paytm patterns
  - Digital arrest, customs, electricity coercion
  - Task/job Telegram scams
  - Shorteners, IP hosts, punycode
  - Legitimate Indian government & bank domains
- Still supports loading external CSVs (PhishTank-style, Kaggle phishing sets, OpenPhish dumps).
- Adds cross-validation, ROC-AUC, feature-importance export.

**How to train**:
```bash
cd backend
PYTHONPATH=.. python -m app.ml.improved_train_url
# or with real data:
PYTHONPATH=.. python -m app.ml.improved_train_url --path /path/to/phishing_urls.csv
```

**Recommended public datasets** (download yourself, respect licences):
- PhishTank online-valid.csv (community verified)
- OpenPhish feed
- Kaggle “Phishing URL Detection (111K)” or “60 Lakh+ Labeled URLs”
- For SMS: UCI SMS Spam Collection + recent Smishing corpora (Smishtank, IMC 2025 sets)

### 2.2 Structured Threat Taxonomy
- New file: `backend/app/ml/threat_taxonomy.py`
- Covers: Urgency Coercion, KYC Harvesting, OTP/PIN Theft, UPI QR Reversal, Digital Arrest, Task/Job Scam, Lottery/Prize, Family Emergency, Phishing URL.
- Each entry contains: description, why it works (psychology), common lures, concrete defence steps, related signals.
- Used by LLM layer and can be injected into API responses for richer UI cards.

### 2.3 LLM Layer (Optional, Privacy-Aware)
- New file: `backend/app/services/llm_layer.py`
- Supports any OpenAI-compatible endpoint (xAI Grok, OpenAI, local Ollama, etc.).
- Environment variables:
  ```
  LLM_API_KEY=...          # or XAI_API_KEY / OPENAI_API_KEY
  LLM_API_BASE=https://api.x.ai/v1
  LLM_MODEL=grok-2-latest
  ```
- Functions:
  - `analyze_message_with_llm()` → structured risk + explanation + actions
  - `explain_url_with_llm()` → human summary of model decision
  - `chatbot_reply()` → adaptive conversation
- Always redacts PII before sending to the model.
- Graceful offline fallback to taxonomy + heuristics when no key or network failure.

**Integration sketch** (in `scamshield.py` or `message_analysis.py`):
```python
from backend.app.services.llm_layer import analyze_message_with_llm, is_llm_available

# after heuristic detection
llm_result = analyze_message_with_llm(message, [s.signal_name for s in detected_signals])
# merge llm_result into the response payload
```

### 2.4 Message-Level ML Path (Recommended Next)
While heuristics remain the explainable first line, a TF-IDF + LinearSVC / RandomForest model on a combined UCI + modern smishing corpus should be added. Skeleton:

```python
# backend/app/ml/message_features.py + train_message_model.py
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
# train on (text, label) pairs, persist vectorizer + model
```

### 2.5 Dataset Ingestion Improvements
Existing `import_datasets.py` already supports CSV. Recommended:
- Add provenance tags (`source=phishtank`, `source=user_report`, `source=synthetic`).
- Store raw feature vectors for future online learning.
- Separate “demonstration” graph from “production” intelligence.

---

## 3. Proper Threat Explanations (Taxonomy Highlights)

### Digital Arrest
Scammers pose as police/CBI/customs, claim a parcel contains drugs or an account is linked to laundering, then force a video-call “digital arrest” and demand payment to a personal UPI/crypto wallet.  
**Why it works**: Authority bias + isolation + fatigue from multi-hour calls.  
**Defence**: Hang up. Real agencies never demand money over WhatsApp or conduct digital arrest. Call 1930 from another phone.

### UPI QR / Collect Reversal
Victim is told “I have sent money — scan this QR to receive”. Scanning + PIN actually *debits* the victim.  
**Golden rule**: You only enter UPI PIN to *send* money. You never need it to *receive*.

### KYC Harvesting
Fake “KYC expired / account will be blocked” SMS → phishing page or direct request for Aadhaar + OTP.  
**Defence**: Banks never ask for full KYC documents or OTP via SMS links. Use official app only.

### Task / Job Scams
Telegram groups promise ₹3k–5k/day for liking videos. Small early payouts, then large “security deposit” or “tax” to unlock frozen earnings.  
**Defence**: Real employers never charge candidates. Leave the group; do not send more money.

(Full structured entries live in `threat_taxonomy.py`.)

---

## 4. Recommended Architecture Going Forward

```
User Message / URL
       │
       ▼
┌──────────────────┐     ┌─────────────────────┐
│ Heuristic Layer  │────▶│ Risk Score + Signals│
│ (explainable)    │     └──────────┬──────────┘
└──────────────────┘                │
                                    ▼
┌──────────────────┐     ┌─────────────────────┐
│ ML Models        │────▶│ Probability + Feats │
│ (URL RF / Msg)   │     └──────────┬──────────┘
└──────────────────┘                │
                                    ▼
┌──────────────────┐     ┌─────────────────────┐
│ LLM Layer        │────▶│ Rich Explanation,   │
│ (optional)       │     │ Actions, Chat       │
└──────────────────┘     └─────────────────────┘
                                    │
                                    ▼
                          API Response + UI Cards
```

Keep the heuristic layer always-on for auditability and offline use. Use ML for ranking / probability. Use LLM for education and adaptive dialogue.

---

## 5. Quick Start for the Improved Components

1. Install any extra deps if needed (`httpx` already present).
2. Train the improved URL model:
   ```bash
   cd backend
   PYTHONPATH=.. python -m app.ml.improved_train_url
   ```
3. (Optional) Set LLM credentials in `.env`:
   ```
   LLM_API_KEY=xai-...
   LLM_API_BASE=https://api.x.ai/v1
   LLM_MODEL=grok-2-latest
   ```
4. Import `threat_taxonomy` and `llm_layer` into the existing analysis endpoints.
5. Re-seed or expand the synthetic graph with real (consented) reports once the model is production-ready.

---

## 6. Remaining Gaps / Future Work

- Message-level supervised model + continuous learning from consented reports.
- Live reputation / WHOIS / certificate checks (optional, behind feature flag, SSRF-safe).
- Multi-language support (Hindi, Hinglish, regional languages).
- Model versioning & A/B evaluation harness.
- Hardening of rate-limit (Redis) and audit logging of model decisions.

---

**Bottom line**: ShieldNet already has a clean, privacy-respecting architecture. The critical missing pieces were data quality, an adaptive explanation layer, and a clear taxonomy of modern threats. The files added in this improvement pass address those gaps while remaining fully compatible with the existing FastAPI + React stack.
